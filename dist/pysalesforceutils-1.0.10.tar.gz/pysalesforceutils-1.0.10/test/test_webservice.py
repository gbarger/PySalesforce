#!/usr/bin/python3
import unittest

requests = 

class TestWebservice(unittest.TestCase):

    def test_http_request(self):
