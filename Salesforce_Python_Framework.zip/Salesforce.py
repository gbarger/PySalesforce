#!usr/bin/python
import json
import WebService
import urllib

class Authentication:
    ##
    # this function logs into Salesforce using the oAuth 2.0 password grant type, and 
    # returns the response that can be used for other salesforce api requests. There
    # are two parts of the response that will be needed, the token, and the instance 
    # url. The token can be retrieved with jsonResponse['access_token'], and the 
    # instance url with jsonResponse['instance_url']. In order for this function to 
    # work, a connected app must be set up in Salesforce, which is where the client 
    # id and client secret come from the Client Id is the connected app Consumer 
    # Key, and the client secret is the consumer secret.
    #
    # @param loginUsername        this is the salesforce login
    # @param loginPassword        this is the salesforce password AND security token
    # @param loginClientId        this is the client Id from the oAuth settings in 
    #                             the Salesforce app setup
    # @param loginClientSecret    this is the secret from the oAuth settings in 
    #                             the Salesforce app setup
    # @param isProduction         this is a boolean value to set whether or not the 
    #                             base oAuth connection will be in production or 
    #                             a sandbox environment
    # @return                     returns the json from the login response body
    #                             the important aspects of the response are the 
    #                             access_token, which will be used to authenticate
    #                             the other calls, and instance_url, which is the
    #                             base endpoint used for the other calls
    ##
    def getOAuthLogin(loginUsername, loginPassword, loginClientId, loginClientSecret, isProduction):
        if isProduction:
            baseOAuthUrl = 'https://login.salesforce.com/services/oauth2/token'
        else:
            baseOAuthUrl = 'https://test.salesforce.com/services/oauth2/token'

        loginBodyData = {'grant_type':'password','client_id':loginClientId,'client_secret':loginClientSecret,'username':loginUsername, 'password':loginPassword}

        response = WebService.Tools.postHTResponse(baseOAuthUrl, loginBodyData, '')
        jsonResponse = json.loads(response.text)

        return jsonResponse

    ##
    # this function calls the correct endpoint for the oauth logout by providing 
    # the token and whether or not the login is production or test.
    #
    # @param authToken            this is the token received in the access_token
    #                             response from the getOAuthLogin function.
    # @param isProduction         this is a boolean value to set whether or not 
    #                             the base oAuth connection will be in production
    #                             or a sandbox environment.
    # @return                     returns a json response with success (True or 
    #                             False), and the status_code returned by the 
    #                             call to revoke the token
    ##
    def getOAuthLogout(authToken, isProduction):
        if isProduction:
            logoutUrl = 'https://login.salesforce.com/services/oauth2/revoke'
        else:
            logoutUrl = 'https://test.salesforce.com/services/oauth2/revoke'

        logoutBodyData = {'host':logoutUrl,'Content-Type':'application/x-www-form-urlencoded','token':authToken}

        response = WebService.Tools.postHTResponse(logoutUrl, logoutBodyData, '')

        success = False
        if response.status_code == 200:
            success = True

        jsonResponse = {'success':success,'status_code':response.status_code}

        return jsonResponse

    def getSoapToken():
        return ''

class Tooling:
    baseToolingUri = '/services/data/v35.0/tooling'

    ##
    # this function executes anonymous apex, and returns a json response object.
    # The response should contain a success value (True or False), column and 
    # line numbers, which return -1 if there are no issues, exceptionStackTrace 
    # which should be None if there are no problems, compiled (True or False), 
    # compileProblem which should be None if there are no problems, and 
    # exceptionMessage if an exception was thrown.
    #
    # @param codeString          this is the non url encoded code string that you
    #                            would like to execute
    # @param accessToken         This is the access_token value received from the 
    #                            login response
    # @param instanceUrl         This is the instance_url value received from the 
    #                            login response
    ##
    def executeAnonymous(codeString, accessToken, instanceUrl):
        executeAnonymousUri = '/executeAnonymous/?anonymousBody='
        headerDetails = {'Authorization': 'Bearer ' + accessToken,'X-PrettyPrint':1}
        urlEncodedCode = urllib.parse.quote(codeString)

        response = WebService.Tools.getHTResponse(instanceUrl + Tooling.baseToolingUri + executeAnonymousUri + urlEncodedCode, headerDetails)
        jsonResponse = json.loads(response.text)

        return jsonResponse